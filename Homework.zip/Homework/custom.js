alert("Thanks for giving this Homework, I actually loved it")
// Declare variables of value type -String,Integer,Float,Boolean,Null and Undefined


let myName = "Mazhar"; //string data type
let age =34;  //integer data type
let perfectAge = 34.5; //float data
let marriage = true; //boolean type data
let ownHouse = null; //i assign null value
let bike = undefined; //i ahve some confusion is it ok or not

console.log ("i have tested all data type")




//Declare an object. (Any Object)

let mazhar = { //here mazhar is a object
    name: "sabuj",
    job: true,
    skills: 5,
}

console.log(mazhar)



//Declare an Array. (Any array)


let car = [ "ferrary" , "BMW", "Aston Martin" , "bugarti"] //string datatype array, as you suggested that use same data type in a array

console.log(car)





//Suppose you have 4 boxes of apples and in them, you have 40, 89, 70, and 65 apples respectively. You have to calculate the total amount of apples.

let box1 = 40;
let box2 = 89;
let box3 = 70;
let box4 = 65;

let totalApple = box1 + box2 + box3 + box4;

console.log("total number of Apple is:" + totalApple)




//Let's assume there is a total of 123 people in a gathering. They all want to go for a picnic. A single bus can contain 35 people. You can use as many buses as you wish. Your role is to calculate how many people will be left behind after completing the busses. [ Be noted: all the buses should be filled completely. 

let totalPleople =123;
let oneBusCapacity =35;

let restPeople = totalPleople % oneBusCapacity;

console.log("Person Cant go for picnic this time is:" + restPeople)